package spring.everytime.com.model.domain;

import spring.everytime.com.model.UserEntity;

public class UserDomain extends UserEntity{
	
}
