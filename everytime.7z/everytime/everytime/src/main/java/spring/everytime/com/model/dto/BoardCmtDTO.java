package spring.everytime.com.model.dto;

import spring.everytime.com.model.BoardCmtEntity;

public class BoardCmtDTO extends BoardCmtEntity {

}
