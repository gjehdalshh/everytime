package spring.everytime.com.model.domain;

import spring.everytime.com.model.BoardCmtCmtEntity;

public class BoardCmtCmtDomain extends BoardCmtCmtEntity{

}
