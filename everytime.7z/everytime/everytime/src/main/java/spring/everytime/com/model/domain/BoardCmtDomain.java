package spring.everytime.com.model.domain;

import spring.everytime.com.model.BoardCmtEntity;

public class BoardCmtDomain extends BoardCmtEntity{

}
