package spring.everytime.com.model.dto;

import spring.everytime.com.model.BoardTypeEntity;

public class BoardTypeDTO extends BoardTypeEntity{

}
