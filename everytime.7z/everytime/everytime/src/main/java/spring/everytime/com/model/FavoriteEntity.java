package spring.everytime.com.model;

public class FavoriteEntity {
	private int i_user;
	private int i_board;
	public int getI_user() {
		return i_user;
	}
	public void setI_user(int i_user) {
		this.i_user = i_user;
	}
	public int getI_board() {
		return i_board;
	}
	public void setI_board(int i_board) {
		this.i_board = i_board;
	}
	
}
