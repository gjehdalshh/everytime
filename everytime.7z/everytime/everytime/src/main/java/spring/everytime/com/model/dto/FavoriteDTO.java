package spring.everytime.com.model.dto;

import spring.everytime.com.model.FavoriteEntity;

public class FavoriteDTO extends FavoriteEntity{

}
