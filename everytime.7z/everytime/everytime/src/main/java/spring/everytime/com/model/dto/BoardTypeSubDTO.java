package spring.everytime.com.model.dto;

import spring.everytime.com.model.BoardTypeSubEntity;

public class BoardTypeSubDTO extends BoardTypeSubEntity{

}
