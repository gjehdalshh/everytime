package spring.everytime.com.model.domain;

import spring.everytime.com.model.BoardTypeSubEntity;

public class BoardTypeSubDomain extends BoardTypeSubEntity{

}
