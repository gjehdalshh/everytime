package spring.everytime.com.model.domain;

import spring.everytime.com.model.FavoriteEntity;

public class FavoriteDomain extends FavoriteEntity{

}
