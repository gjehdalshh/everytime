package spring.everytime.com.model.domain;

import spring.everytime.com.model.BoardTypeEntity;

public class BoardTypeDomain extends BoardTypeEntity{

	private String board_nm;

	public String getBoard_nm() {
		return board_nm;
	}

	public void setBoard_nm(String board_nm) {
		this.board_nm = board_nm;
	}
}
