package spring.everytime.com.model.dto;

import spring.everytime.com.model.BoardCmtCmtEntity;

public class BoardCmtCmtDTO extends BoardCmtCmtEntity{

}
