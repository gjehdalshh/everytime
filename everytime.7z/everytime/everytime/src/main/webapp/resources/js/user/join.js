var btn_join = document.querySelector('#btn_join')

btn_join.onclick = function() {
	
	
}